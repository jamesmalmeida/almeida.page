int porta_LED_VERDE_CARRO = 4;
int porta_LED_AMARELO_CARRO = 5;
int porta_LED_VERMELHO_CARRO = 6;
int porta_LED_VERDE_PEDESTRE = 7;
int porta_LED_VERMELHO_PEDESTRE = 8;
int porta_botao = 9;
int botao_pressionado = 0;

void setup() {
  pinMode(porta_LED_VERDE_CARRO, OUTPUT);
  pinMode(porta_LED_AMARELO_CARRO, OUTPUT);
  pinMode(porta_LED_VERMELHO_CARRO, OUTPUT);
  pinMode(porta_LED_VERDE_PEDESTRE, OUTPUT);
  pinMode(porta_LED_VERMELHO_PEDESTRE, OUTPUT);
  pinMode(porta_botao, INPUT_PULLUP);
  Serial.begin(9600);
}

// the loop function runs over and over again forever
void loop() {
  digitalWrite(porta_LED_VERMELHO_PEDESTRE, HIGH);
  while (botao_pressionado == 0) {
    botao_pressionado = acende_led(porta_LED_VERMELHO_CARRO, 2000);
    desliga_led(porta_LED_VERMELHO_CARRO);
    botao_pressionado = acende_led(porta_LED_AMARELO_CARRO, 500);
    desliga_led(porta_LED_AMARELO_CARRO);
    botao_pressionado = acende_led(porta_LED_VERDE_CARRO, 2000);
    desliga_led(porta_LED_VERDE_CARRO);
  }
  //digitalWrite(porta_LED_AMARELO_CARRO, HIGH);
  //delay(500);
  //digitalWrite(porta_LED_AMARELO_CARRO, LOW);
  digitalWrite(porta_LED_VERMELHO_CARRO, HIGH);
  delay(1000);
  digitalWrite(porta_LED_VERMELHO_PEDESTRE, LOW);
  digitalWrite(porta_LED_VERDE_PEDESTRE, HIGH);
  botao_pressionado = 0;
  delay(2000);
  digitalWrite(porta_LED_VERDE_PEDESTRE, LOW);
}

void acende_desliga_led(int porta, int tempo_aceso_ms) {
  digitalWrite(porta, HIGH);
  delay(tempo_aceso_ms);
  digitalWrite(porta, LOW);
}

int acende_led(int porta, int tempo) {
  int ciclos = 500;
  int tempo_loop =  tempo/ciclos;
  int botao = 0;
  //tempo_loop =  tempo/ciclos;
  for (int contador = 0; contador < ciclos; contador++) {
    digitalWrite(porta, HIGH);
    delay(tempo_loop);
    if (digitalRead(porta_botao) == LOW) {
      botao = 1;
    }
    //Serial.print(botao);
  }
  return botao;
}

void desliga_led(int porta) {
  digitalWrite(porta, LOW);
}
