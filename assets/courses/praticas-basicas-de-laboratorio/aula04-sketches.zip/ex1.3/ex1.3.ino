#include <Ultrasonic.h>
int pino_echo = 8;
int pino_trig = 9;
float leitura;

int pino_led_vermelho = 5;
int pino_led_amarelo = 6;
int pino_led_verde = 7;

Ultrasonic sensor_us(pino_trig, pino_echo);

void setup() {
  Serial.begin(9600);
  pinMode(pino_led_vermelho, OUTPUT);
  pinMode(pino_led_amarelo, OUTPUT);
  pinMode(pino_led_verde, OUTPUT);
  digitalWrite(pino_led_vermelho, LOW);
  digitalWrite(pino_led_amarelo, LOW);
  digitalWrite(pino_led_verde, LOW);
}

void loop() {
  leitura = sensor_us.read(); // lê a distância em centímetros
  Serial.print("Distancia(cm):");
  Serial.print(leitura);
  Serial.println();

  if (leitura < 30) {
    digitalWrite(pino_led_vermelho, HIGH);
    digitalWrite(pino_led_amarelo, LOW);
    digitalWrite(pino_led_verde, LOW);
  }
  else if (leitura > 30 && leitura <= 60) {
    digitalWrite(pino_led_vermelho, LOW);
    digitalWrite(pino_led_amarelo, HIGH);
    digitalWrite(pino_led_verde, LOW);    
  }
  else if (leitura >= 60) {
    digitalWrite(pino_led_vermelho, LOW);
    digitalWrite(pino_led_amarelo, LOW);
    digitalWrite(pino_led_verde, HIGH);    
  }
  
  delay(200);
}
