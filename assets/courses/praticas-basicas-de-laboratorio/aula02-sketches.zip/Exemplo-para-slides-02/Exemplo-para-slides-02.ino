int tempo_t = 500; // Define a variável inteira tempo_t como 500

// Começamos com o bloco de configuração.
void setup() {
  // Inicializa o LED interno com a função pinMode, que leva dois argumentos
  // O primeiro argumento é a porta que queremos inicializar, no caso é o LED interno, que tem uma constante dedicada a LED_BUILTIN
  // O segundo argumento é o mode que ficara a porta, no caso é OUTPUT, que configura a porta para modo de saída de sinal
  pinMode(LED_BUILTIN, OUTPUT);
}

// A seguir fica o blobo de laço (loop), que se repete infinitamente.
void loop() {
  // A função digitalWrite altera o modo de operação de uma porta, levando dois argumentos.
  // O primeiro argumento é a porta que queremos alterar, no caso a LED_BUILTIN
  // O segundo argumento é o modo de operação, que pode ser HIGH ou LOW.
  // No caso, HIGH é o LED acesso e LOW é o LED apagado.
  digitalWrite(LED_BUILTIN, HIGH);   // Liga o LED interno.
  // A função delay pausa o código, o argumento é o tempo os ms que o código espera.
  delay(tempo_t);                    // Espera por tempo_t ms.
  digitalWrite(LED_BUILTIN, LOW);    // Desliga o LED interno.
  delay(tempo_t);                    // Esperar por tempo_t ms.
}
