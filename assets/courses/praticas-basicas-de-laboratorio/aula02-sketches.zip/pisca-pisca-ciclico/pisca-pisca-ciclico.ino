int tempo_t = 500;

void setup() {
  // put your setup code here, to run once:
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);
}

void loop() {
  // put your main code here, to run repeatedly:

  if (tempo_t == 2000) {
    tempo_t = 500;
  }

  digitalWrite(LED_BUILTIN, HIGH);
  delay(tempo_t);
  digitalWrite(LED_BUILTIN, LOW);
  delay(tempo_t);

  tempo_t = tempo_t + 100;
}
