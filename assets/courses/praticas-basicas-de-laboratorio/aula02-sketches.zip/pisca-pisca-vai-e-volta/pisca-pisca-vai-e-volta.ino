int tempo_t = 500;
boolean sobe = true;

void setup() {
  // put your setup code here, to run once:
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, HIGH);
}

void loop() {
  // put your main code here, to run repeatedly:

  digitalWrite(LED_BUILTIN, HIGH);
  delay(tempo_t);
  digitalWrite(LED_BUILTIN, LOW);
  delay(tempo_t);

  if (sobe == true) {
    tempo_t = tempo_t + 100;
  }
  else if (sobe == false) {
    tempo_t = tempo_t - 100;
  }

  if (tempo_t == 2000 && sobe == true) {
    sobe = false;
  }
  if (tempo_t == 500) {
    sobe = true;
  }
}