int porta1 = 6;
int porta2 = 7;

void setup() {
  pinMode(porta1, OUTPUT);
  pinMode(porta2, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  digitalWrite(porta1, HIGH);   // turn the LED on (HIGH is the voltage level)
  digitalWrite(porta2, LOW);   // turn the LED on (HIGH is the voltage level)
  delay(1000);                       // wait for a second
  digitalWrite(porta1, LOW);    // turn the LED off by making the voltage LO
  digitalWrite(porta2, HIGH);   // turn the LED on (HIGH is the voltage level)
  delay(1000);                       // wait for a second
}
