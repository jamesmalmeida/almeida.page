int porta = 6;

void setup() {
  pinMode(porta, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  digitalWrite(porta, HIGH);   // turn the LED on (HIGH is the voltage level)
  delay(1000);                       // wait for a second
  digitalWrite(porta, LOW);    // turn the LED off by making the voltage LOW
  delay(1000);                       // wait for a second
}
