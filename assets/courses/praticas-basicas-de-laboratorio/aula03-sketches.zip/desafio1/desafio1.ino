  int porta_LED1 = 5;
int porta_LED2 = 6;
int porta_LED3 = 7;
int porta_LED4 = 8;
int porta_LED5 = 9;
int porta_botao = 10;

void setup() {
  pinMode(porta_LED1, OUTPUT);
  pinMode(porta_LED2, OUTPUT);
  pinMode(porta_LED3, OUTPUT);
  pinMode(porta_LED4, OUTPUT);
  pinMode(porta_LED5, OUTPUT);
  pinMode(porta_botao, INPUT_PULLUP);
}

// the loop function runs over and over again forever
void loop() {
  if (digitalRead(porta_botao) == HIGH) {
    digitalWrite(porta_LED5, LOW);
    digitalWrite(porta_LED4, HIGH);
    acende_led(porta_LED3, 1000);
    acende_led(porta_LED2, 200);
    acende_led(porta_LED1, 1000);
  }
  else if (digitalRead(porta_botao) == LOW) {
    digitalWrite(porta_LED3, HIGH);
    digitalWrite(porta_LED4, LOW);
    digitalWrite(porta_LED5, HIGH);
    delay(10000);
    digitalWrite(porta_LED3, LOW);
  }
}

void acende_led(int porta, int tempo_aceso_ms) {
  digitalWrite(porta, HIGH);
  delay(tempo_aceso_ms);
  digitalWrite(porta, LOW);
}