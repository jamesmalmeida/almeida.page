int porta_LED1 = 5;
int porta_LED2 = 6;
int porta_LED3 = 7;
int porta_LED4 = 8;
int porta_LED5 = 9;

void setup() {
  pinMode(porta_LED1, OUTPUT);
  pinMode(porta_LED2, OUTPUT);
  pinMode(porta_LED3, OUTPUT);
  pinMode(porta_LED4, OUTPUT);
  pinMode(porta_LED5, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  digitalWrite(porta_LED5, LOW);
  digitalWrite(porta_LED4, HIGH);
  //delay(1000);
  acende_led(porta_LED3, 1000);
  acende_led(porta_LED2, 300);
  acende_led(porta_LED1, 1000);

  digitalWrite(porta_LED3, HIGH);
  delay(1000);
  digitalWrite(porta_LED4, LOW);
  digitalWrite(porta_LED5, HIGH);
  delay(1000);
  digitalWrite(porta_LED3, LOW);
}

void acende_led(int porta, int tempo_aceso_ms) {
  digitalWrite(porta, HIGH);
  delay(tempo_aceso_ms);
  digitalWrite(porta, LOW);
}