int porta_LED = 6;
int porta_botao = 7;

void setup() {
    pinMode(porta_LED, OUTPUT);
    pinMode(porta_botao, INPUT_PULLUP);
}

void loop () {
    if (digitalRead(porta_botao) == LOW) {
        digitalWrite(porta_LED, HIGH);
    }
    else if (digitalRead(porta_botao) == HIGH) {
        digitalWrite(porta_LED, LOW);
    }
    delay(1000);
}