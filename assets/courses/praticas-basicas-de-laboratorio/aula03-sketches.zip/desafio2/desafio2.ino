int porta_LED1 = 4;
int porta_LED2 = 5;
int porta_LED3 = 6;
int porta_LED4 = 7;
int porta_LED5 = 8;
int porta_LED6 = 9;
int dado1;
int dado2;
int dado3;
int dado4;
int dado5;
int dado6;

void setup() {
  pinMode(porta_LED1, OUTPUT);
  pinMode(porta_LED2, OUTPUT);
  pinMode(porta_LED3, OUTPUT);
  pinMode(porta_LED4, OUTPUT);
  pinMode(porta_LED5, OUTPUT);
  pinMode(porta_LED6, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  dado1 = random(0,2);
  dado2 = random(0,2);
  dado3 = random(0,2);
  dado4 = random(0,2);
  dado5 = random(0,2);
  dado6 = random(0,2);
  if (dado1 == 1) {
    digitalWrite(porta_LED1, HIGH);
  }
  if (dado2 == 1) {
    digitalWrite(porta_LED2, HIGH);
  }
  if (dado3 == 1) {
    digitalWrite(porta_LED3, HIGH);
  }
  if (dado4 == 1) {
    digitalWrite(porta_LED4, HIGH);
  }
  if (dado5 == 1) {
    digitalWrite(porta_LED5, HIGH);
  }
  if (dado6 == 1) {
    digitalWrite(porta_LED6, HIGH);
  }
  delay(300);
  digitalWrite(porta_LED1, LOW);
  digitalWrite(porta_LED2, LOW);
  digitalWrite(porta_LED3, LOW);
  digitalWrite(porta_LED4, LOW);
  digitalWrite(porta_LED5, LOW);
  digitalWrite(porta_LED6, LOW);
  delay(300);
}