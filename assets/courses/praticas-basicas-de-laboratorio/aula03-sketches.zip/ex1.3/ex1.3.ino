int porta_LED1 = 6;
int porta_LED2 = 7;
int porta_input_botao = 8;

void setup() {
  pinMode(porta_LED1, OUTPUT);
  pinMode(porta_LED2, OUTPUT);
  pinMode(porta_input_botao, INPUT_PULLUP);
  pinMode(porta_fonte_botao, OUTPUT);
}

// the loop function runs over and over again forever
void loop() {
  if (digitalRead(porta_input_botao) == LOW) {
    digitalWrite(porta_LED1, HIGH);   // turn the LED on (HIGH is the voltage level)
    digitalWrite(porta_LED2, LOW);   // turn the LED on (HIGH is the voltage level)
    delay(2000);                       // wait for a second
    digitalWrite(porta_LED1, LOW);    // turn the LED off by making the voltage LO
    digitalWrite(porta_LED2, HIGH);   // turn the LED on (HIGH is the voltage level)
    delay(2000);                       // wait for a second
  }
  else if (digitalRead(porta_input_botao) == HIGH) {
    digitalWrite(porta_LED1, HIGH);   // turn the LED on (HIGH is the voltage level)
    digitalWrite(porta_LED2, LOW);   // turn the LED on (HIGH is the voltage level)
    delay(200);                       // wait for a second
    digitalWrite(porta_LED1, LOW);    // turn the LED off by making the voltage LO
    digitalWrite(porta_LED2, HIGH);   // turn the LED on (HIGH is the voltage level)
    delay(200);                       // wait for a second
  }
  else {
    delay(2000);
  }

}
