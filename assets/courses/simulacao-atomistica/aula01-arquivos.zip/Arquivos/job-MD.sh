#!/bin/bash

#SBATCH --partition=cpu
#SBATCH --job-name=argon
#SBATCH --ntasks=1

module load amber/2024

pmemd -O -i min.in       -o min.out       -p system.prmtop -c system.inpcrd -r min.rst7      -x min.nc       -inf min.mdinfo       -ref system.inpcrd  #Minimização
pmemd -O -i nvt.in       -o nvt.out       -p system.prmtop -c min.rst7      -r nvt.rst7      -x nvt.nc       -inf nvt.mdinfo       -ref min.rst7       #Termalização
pmemd -O -i npt_equ.in   -o npt_equ.out   -p system.prmtop -c nvt.rst7      -r npt_equ.rst7  -x npt_equ.nc   -inf npt_equ.mdinfo   -ref nvt.rst7       #Equilibração
pmemd -O -i npt_prod.in  -o npt_prod.out  -p system.prmtop -c npt_equ.rst7  -r npt_prod.rst7 -x npt_prod.nc  -inf npt_prod.mdinfo  -ref npt_equ.rst7   #Produção
