#!/bin/bash

#SBATCH --partition=batch-AMD
#SBATCH --job-name=argon
#SBATCH --ntasks=1

module load amber/2023

cpptraj < cpptraj.in > cpptraj.out
