#!/bin/bash
#SBATCH -n 16
#SBATCH --ntasks-per-node=16
#SBATCH -p batch-AMD
#SBATCH --mem=128000mb

module load vasp/6.2.0

hostname
export OMP_NUM_THREADS=1
mpirun -n 16 vasp_std > vasp.out
